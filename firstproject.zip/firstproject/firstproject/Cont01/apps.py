from django.apps import AppConfig


class Cont01Config(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'Cont01'
